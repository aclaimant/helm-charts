# Aclaimant NGINX Helm Chart

A Helm chart for deploying the aclaimant NGINX reverse proxy with SSL termination and microservice routing.

## Overview

This chart deploys an NGINX reverse proxy that:
- Handles SSL termination for aclaimant.com domains
- Routes traffic to multiple backend microservices
- Supports multiple environments (dev, staging, demo, sandbox, production)
- Uses AWS Network Load Balancer (NLB) for internet-facing traffic
- Contains all configurations baked into the Docker image

## Architecture

### How It Works

```
Internet → AWS NLB (LoadBalancer) → NGINX Pods → Backend Services
           (Port 80/443)              (ACL_ENV)   (Kubernetes services)
```

1. **Docker Image**: `aclaimant/nginx-ps` contains all nginx configurations for all environments
2. **Runtime Selection**: `ACL_ENV` environment variable determines which config is used
3. **Service Discovery**: NGINX routes to Kubernetes services via cluster DNS
4. **SSL Termination**: SSL certificates are baked into the Docker image

### Configuration Selection

The `setup-nginx` script in the Docker image selects the appropriate nginx config based on `ACL_ENV`:

| ACL_ENV Value | Config File | Environment |
|---------------|-------------|-------------|
| `development` | `dev.nginx.conf` | Development |
| `staging` | `staging.nginx.conf` | Staging |
| `demo` | `demo.nginx.conf` | Demo |
| `sandbox` | `sandbox.nginx.conf` | Sandbox |
| `production` | `prod.nginx.conf` | Production |

**Important**: The `ACL_ENV` value must match exactly (case-sensitive).

## Versioning Strategy

This chart uses **independent versioning** for chart and application:

### Chart Version (`version` in Chart.yaml)

Represents the **chart itself** - templates, values, deployment logic.

**Bump when**:
- Chart templates change
- New configuration options added
- Template logic modified
- Values structure changes

**Semantic Versioning**:
- `MAJOR`: Breaking changes to values or templates
- `MINOR`: New features, backward-compatible
- `PATCH`: Bug fixes, documentation

**Example**: `1.0.0` → `1.1.0` (added new health probe option)

### App Version (`appVersion` in Chart.yaml)

Represents the **default Docker image version** being deployed.

**Bump when** (optional):
- New Docker image is built
- Want to update default deployment version

**Override at deploy time**:
```bash
helm install ... --set image.tag=1.0.18
```

**Example**: Chart `1.0.0` can deploy app versions `1.0.17`, `1.0.18`, `1.0.19`, etc.

### Typical Workflow

```bash
# Deploy new app version without chart change
helm upgrade aclaimant-nginx aclaimant/aclaimant-nginx \
  --set image.tag=1.0.18 \
  --reuse-values

# Update chart itself (templates/values changed)
# 1. Edit templates or values
# 2. Update version in Chart.yaml: 1.0.0 → 1.1.0
# 3. Publish chart (see below)
```

## Publishing the Chart

### Prerequisites

1. **Helm Charts Repository**: Create `github.com/aclaimant/helm-charts` (public)
2. **GitHub Pages**: Enabled on `gh-pages` branch
3. **SSH Access**: Configured for GitHub

### Using the Publish Script

```bash
# From the nginx repo root
./publish-chart.sh
```

This will:
1. Package the chart as a `.tgz` file
2. Clone/update the helm-charts repo
3. Add the package to the helm repository index
4. Push to GitHub (publishes via GitHub Pages)

### Manual Publishing

```bash
# Package the chart
helm package helm/aclaimant-nginx

# Clone helm-charts repo
git clone git@github.com:aclaimant/helm-charts.git
cd helm-charts
git checkout gh-pages || git checkout -b gh-pages

# Copy package and update index
mv ../aclaimant-nginx-*.tgz .
helm repo index . --url https://aclaimant.github.io/helm-charts

# Commit and push
git add .
git commit -m "Update aclaimant-nginx chart"
git push origin gh-pages
```

### Verifying Publication

```bash
# Add the repository
helm repo add aclaimant https://aclaimant.github.io/helm-charts
helm repo update

# Search for the chart
helm search repo aclaimant
# Should show: aclaimant/aclaimant-nginx
```

## Installation

### Adding the Helm Repository

```bash
helm repo add aclaimant https://aclaimant.github.io/helm-charts
helm repo update
```

### Installing the Chart

#### Staging Environment

```bash
helm install aclaimant-nginx aclaimant/aclaimant-nginx \
  -f values-staging.yaml \
  --namespace default
```

#### Production Environment

```bash
helm install aclaimant-nginx aclaimant/aclaimant-nginx \
  -f values-prod.yaml \
  --namespace default
```

#### With Custom Image Version

```bash
helm install aclaimant-nginx aclaimant/aclaimant-nginx \
  -f values-staging.yaml \
  --set image.tag=1.0.18 \
  --namespace default
```

### Upgrading the Chart

```bash
# Upgrade to new chart version
helm repo update
helm upgrade aclaimant-nginx aclaimant/aclaimant-nginx \
  -f values-staging.yaml \
  --namespace default

# Upgrade to new image version
helm upgrade aclaimant-nginx aclaimant/aclaimant-nginx \
  --set image.tag=1.0.19 \
  --reuse-values
```

### Uninstalling the Chart

```bash
helm uninstall aclaimant-nginx --namespace default
```

## Configuration

### Key Values

| Parameter | Description | Default |
|-----------|-------------|---------|
| `replicaCount` | Number of NGINX pods | `2` |
| `image.repository` | Docker image repository | `index.docker.io/aclaimant/nginx-ps` |
| `image.tag` | Docker image tag | `""` (uses appVersion) |
| `image.pullPolicy` | Image pull policy | `Always` |
| `environment.aclEnv` | Environment selector | `staging` |
| `service.type` | Kubernetes service type | `LoadBalancer` |
| `service.annotations` | Service annotations (NLB config) | See values.yaml |
| `resources.requests.cpu` | CPU request | `50m` |
| `resources.requests.memory` | Memory request | `256Mi` |
| `resources.limits` | Resource limits | `{}` |
| `namespace` | Kubernetes namespace | `default` |

### Environment-Specific Values

Each environment has a dedicated values file that overrides the defaults:

#### `values-dev.yaml` (Development)
- **Replicas**: 1
- **ACL_ENV**: `development`
- **CPU**: 25m
- **Memory**: 128Mi
- **Use case**: Local development cluster

#### `values-staging.yaml` (Staging)
- **Replicas**: 2
- **ACL_ENV**: `staging`
- **CPU**: 50m
- **Memory**: 256Mi
- **Use case**: Pre-production testing

#### `values-demo.yaml` (Demo)
- **Replicas**: 2
- **ACL_ENV**: `demo`
- **CPU**: 50m
- **Memory**: 256Mi
- **Use case**: Customer demos

#### `values-sandbox.yaml` (Sandbox)
- **Replicas**: 2
- **ACL_ENV**: `sandbox`
- **CPU**: 50m
- **Memory**: 256Mi
- **Use case**: Sandman service integration testing

#### `values-prod.yaml` (Production)
- **Replicas**: 3
- **ACL_ENV**: `production`
- **CPU**: 100m
- **Memory**: 512Mi
- **Memory Limit**: 1Gi
- **Use case**: Production workloads

## Deployment Examples

### Using with Porter Cloud

1. **Create helm-charts addon**:
   - Helm Repository URL: `https://aclaimant.github.io/helm-charts`
   - Chart Name: `aclaimant-nginx`
   - Version: `1.0.0`

2. **Configure values**:
   ```yaml
   environment:
     aclEnv: "staging"
   replicaCount: 2
   image:
     tag: "1.0.17"
   ```

3. **Deploy** via Porter UI or CLI

### Local Development

```bash
# Clone the repo
git clone https://github.com/aclaimant/nginx.git
cd nginx

# Test template rendering
helm template aclaimant-nginx ./helm/aclaimant-nginx \
  -f ./helm/aclaimant-nginx/values-dev.yaml

# Install locally
helm install aclaimant-nginx ./helm/aclaimant-nginx \
  -f ./helm/aclaimant-nginx/values-dev.yaml \
  --namespace default
```

### CI/CD Pipeline

```bash
# In your CI/CD pipeline
helm upgrade --install aclaimant-nginx aclaimant/aclaimant-nginx \
  -f values-${ENVIRONMENT}.yaml \
  --set image.tag=${IMAGE_TAG} \
  --namespace default \
  --wait
```

## Important Notes

### ⚠️ ACL_ENV Must Match Exactly

The `environment.aclEnv` value is **case-sensitive** and must match one of:
- `development`
- `demo`
- `staging`
- `sandbox`
- `production`

**Incorrect values will cause nginx to fail at startup.**

### ⚠️ Backend Service Dependencies

NGINX routes to these backend services (example for staging):
- `acl-service-staging-web.default.svc.cluster.local:80`
- `acl-alerter-staging-web.default.svc.cluster.local:80`
- `acl-twilio-staging-web.default.svc.cluster.local:80`
- `acl-jobs-staging-web.default.svc.cluster.local:80`
- `acl-paper-pusher-staging-web.default.svc.cluster.local:80`
- `acl-playwright-pdf-staging-web.default.svc.cluster.local:80`

**These services must exist before deploying NGINX**, or NGINX will fail health checks.

### ⚠️ SSL Certificates

SSL certificates are **baked into the Docker image** at `/sites/aclaimant/`:
- Current certificate: `aclaimant.com.20250414.crt` (expires April 2025)
- Certificate renewal requires **rebuilding the Docker image**
- No runtime certificate management

### ⚠️ LoadBalancer Provisioning

AWS NLB provisioning takes **2-5 minutes**. Monitor with:

```bash
kubectl get service aclaimant-nginx -n default -w
```

Wait for `EXTERNAL-IP` to change from `<pending>` to an AWS hostname.

### ⚠️ DNS Configuration

When migrating or deploying:
1. Wait for LoadBalancer to provision
2. Note the `EXTERNAL-IP` (AWS NLB hostname)
3. Update DNS records:
   - `aclaimant.com` → CNAME to NLB
   - `*.aclaimant.com` → CNAME to NLB
4. Test with: `curl -I https://staging.aclaimant.com`

## Troubleshooting

### Pods Not Starting

**Check logs**:
```bash
kubectl logs -l app.kubernetes.io/name=aclaimant-nginx -n default
```

**Common causes**:
- Invalid `ACL_ENV` value (check exact spelling)
- Backend services not available
- Image pull errors

### Service Not Getting External IP

**Check service**:
```bash
kubectl describe service aclaimant-nginx -n default
```

**Common causes**:
- AWS NLB annotations missing
- Insufficient AWS permissions
- VPC/subnet configuration issues
- Service quota limits

### 502/503 Errors

**Check upstream services**:
```bash
# List all services
kubectl get services -n default

# Check specific backend
kubectl get pods -l app=acl-service-staging -n default
```

**Common causes**:
- Backend service not running
- Backend service port mismatch
- Service DNS not resolving

### Configuration Not Applied

**Verify ACL_ENV**:
```bash
kubectl get deployment aclaimant-nginx -n default -o yaml | grep ACL_ENV
```

**Restart pods**:
```bash
kubectl rollout restart deployment aclaimant-nginx -n default
```

### Certificate Errors

SSL certificates are in the Docker image. To update:

1. Update certificate files in nginx repo
2. Rebuild Docker image: `./build`
3. Push to Docker Hub
4. Update helm deployment with new image tag

## Development

### Local Testing

```bash
# Validate chart syntax
helm lint ./helm/aclaimant-nginx

# Test template rendering
helm template aclaimant-nginx ./helm/aclaimant-nginx \
  -f ./helm/aclaimant-nginx/values-staging.yaml

# Dry-run (validates against cluster)
helm install aclaimant-nginx ./helm/aclaimant-nginx \
  -f ./helm/aclaimant-nginx/values-staging.yaml \
  --dry-run --debug \
  --namespace default
```

### Making Changes

1. **Edit templates or values**
2. **Test locally**:
   ```bash
   helm lint ./helm/aclaimant-nginx
   helm template test ./helm/aclaimant-nginx -f values-staging.yaml
   ```
3. **Bump chart version** in `Chart.yaml` (if templates changed)
4. **Commit changes** to nginx repo
5. **Publish chart**: `./publish-chart.sh`
6. **Test deployment**:
   ```bash
   helm repo update
   helm upgrade aclaimant-nginx aclaimant/aclaimant-nginx -f values-staging.yaml
   ```

### Chart Structure

```
helm/aclaimant-nginx/
├── Chart.yaml              # Chart metadata and versions
├── values.yaml             # Default values (template)
├── values-{env}.yaml       # Environment-specific overrides
├── .helmignore             # Files to exclude from package
└── templates/
    ├── _helpers.tpl        # Template helper functions
    ├── deployment.yaml     # Kubernetes Deployment
    ├── service.yaml        # Kubernetes Service (LoadBalancer)
    ├── serviceaccount.yaml # Kubernetes ServiceAccount
    └── NOTES.txt           # Post-install instructions
```

## Additional Resources

- [Helm Documentation](https://helm.sh/docs/)
- [Kubernetes Services](https://kubernetes.io/docs/concepts/services-networking/service/)
- [AWS Load Balancer Controller](https://kubernetes-sigs.github.io/aws-load-balancer-controller/)
- [NGINX Documentation](https://nginx.org/en/docs/)

## Support

For issues or questions:
- Check the [Troubleshooting](#troubleshooting) section
- Review pod logs: `kubectl logs -l app.kubernetes.io/name=aclaimant-nginx`
- Check service status: `kubectl describe service aclaimant-nginx`
- Contact the infrastructure team
